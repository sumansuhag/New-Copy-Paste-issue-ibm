import { useState, useRef, useEffect } from 'react';
import { Dataset, Selection } from '../types';
import { copyToClipboard } from '../utils/clipboard';

interface DataGridProps {
  dataset: Dataset;
  onUpdateCell: (rowId: string, colIndex: number, value: string) => void;
  onPaste: (startRow: number, startCol: number, cells: any[][]) => void;
  onDeleteRow: (rowId: string) => void;
  onDeleteColumn: (colIndex: number) => void;
}

export const DataGrid = ({
  dataset,
  onUpdateCell,
  onPaste,
  onDeleteRow,
  onDeleteColumn,
}: DataGridProps) => {
  const [selection, setSelection] = useState<Selection | null>(null);
  const [editingCell, setEditingCell] = useState<{ rowId: string; colIndex: number } | null>(null);
  const [focusedCell, setFocusedCell] = useState<{ rowId: string; colIndex: number } | null>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  const getRowIndex = (rowId: string) => dataset.rows.findIndex(r => r.id === rowId);
  const getRowId = (index: number) => dataset.rows[index]?.id;

  const handleCellClick = (rowId: string, colIndex: number, event: React.MouseEvent) => {
    if (event.shiftKey && focusedCell) {
      const startRow = getRowIndex(focusedCell.rowId);
      const endRow = getRowIndex(rowId);
      const startCol = focusedCell.colIndex;
      const endCol = colIndex;
      
      setSelection({
        startRow: Math.min(startRow, endRow),
        endRow: Math.max(startRow, endRow),
        startCol: Math.min(startCol, endCol),
        endCol: Math.max(startCol, endCol),
      });
    } else {
      setSelection({
        startRow: getRowIndex(rowId),
        endRow: getRowIndex(rowId),
        startCol: colIndex,
        endCol: colIndex,
      });
      setFocusedCell({ rowId, colIndex });
    }
  };

  const handleCellDoubleClick = (rowId: string, colIndex: number) => {
    setEditingCell({ rowId, colIndex });
  };

  const handleKeyDown = (e: React.KeyboardEvent, rowId: string, colIndex: number) => {
    const rowIndex = getRowIndex(rowId);
    
    if (e.key === 'Enter' && !editingCell) {
      e.preventDefault();
      handleCellDoubleClick(rowId, colIndex);
      return;
    }
    
    if (editingCell) {
      if (e.key === 'Enter' || e.key === 'Escape') {
        e.preventDefault();
        setEditingCell(null);
        return;
      }
      return;
    }

    if (e.key === 'Delete' || e.key === 'Backspace') {
      if (selection) {
        for (let r = selection.startRow; r <= selection.endRow; r++) {
          for (let c = selection.startCol; c <= selection.endCol; c++) {
            onUpdateCell(getRowId(r)!, c, '');
          }
        }
        setSelection(null);
      }
      return;
    }

    if (e.key === 'ArrowDown' && rowIndex < dataset.rows.length - 1) {
      e.preventDefault();
      const newRowId = getRowId(rowIndex + 1)!;
      setFocusedCell({ rowId: newRowId, colIndex });
      setSelection({ startRow: rowIndex + 1, endRow: rowIndex + 1, startCol: colIndex, endCol: colIndex });
    }
    if (e.key === 'ArrowUp' && rowIndex > 0) {
      e.preventDefault();
      const newRowId = getRowId(rowIndex - 1)!;
      setFocusedCell({ rowId: newRowId, colIndex });
      setSelection({ startRow: rowIndex - 1, endRow: rowIndex - 1, startCol: colIndex, endCol: colIndex });
    }
    if (e.key === 'ArrowRight' && colIndex < dataset.columns.length - 1) {
      e.preventDefault();
      setFocusedCell({ rowId, colIndex: colIndex + 1 });
      setSelection({ startRow: rowIndex, endRow: rowIndex, startCol: colIndex + 1, endCol: colIndex + 1 });
    }
    if (e.key === 'ArrowLeft' && colIndex > 0) {
      e.preventDefault();
      setFocusedCell({ rowId, colIndex: colIndex - 1 });
      setSelection({ startRow: rowIndex, endRow: rowIndex, startCol: colIndex - 1, endCol: colIndex - 1 });
    }

    if (e.key === 'c' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      handleCopy();
    }
    if (e.key === 'v' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      handlePaste();
    }
  };

  const handleCopy = () => {
    if (!selection) return;
    
    const cells: any[][] = [];
    for (let r = selection.startRow; r <= selection.endRow; r++) {
      const row: any[] = [];
      for (let c = selection.startCol; c <= selection.endCol; c++) {
        row.push(dataset.rows[r]?.cells[c] || { value: '', type: 'string' });
      }
      cells.push(row);
    }
    
    copyToClipboard(cells);
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      const { parseTSV } = await import('../utils/clipboard');
      const cells = parseTSV(text);
      
      const startRow = selection ? selection.startRow : getRowIndex(focusedCell?.rowId || dataset.rows[0]?.id);
      const startCol = selection ? selection.startCol : focusedCell?.colIndex || 0;
      
      onPaste(startRow, startCol, cells);
    } catch (err) {
      console.error('Paste failed:', err);
    }
  };

  const isCellSelected = (rowIndex: number, colIndex: number) => {
    if (!selection) return false;
    return (
      rowIndex >= selection.startRow &&
      rowIndex <= selection.endRow &&
      colIndex >= selection.startCol &&
      colIndex <= selection.endCol
    );
  };

  const isCellFocused = (rowId: string, colIndex: number) => {
    return focusedCell?.rowId === rowId && focusedCell?.colIndex === colIndex;
  };

  return (
    <div className="overflow-auto border border-slate-300 bg-white" ref={gridRef}>
      <table className="w-full border-collapse">
        <thead className="bg-slate-100 sticky top-0">
          <tr>
            <th className="w-10 p-2 text-xs font-medium text-slate-500 border border-slate-300 bg-slate-50">#</th>
            {dataset.columns.map((col, colIndex) => (
              <th
                key={col}
                className="p-2 text-xs font-medium text-slate-700 border border-slate-300 bg-slate-100 min-w-[120px]"
              >
                {col}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {dataset.rows.map((row, rowIndex) => (
            <tr key={row.id} className="hover:bg-slate-50">
              <td className="p-2 text-xs text-slate-400 border border-slate-300 bg-slate-50 text-center">
                {rowIndex + 1}
              </td>
              {row.cells.map((cell, colIndex) => {
                const isSelected = isCellSelected(rowIndex, colIndex);
                const isFocused = isCellFocused(row.id, colIndex);
                const isEditing = editingCell?.rowId === row.id && editingCell?.colIndex === colIndex;
                
                return (
                  <td
                    key={`${row.id}-${colIndex}`}
                    className={`
                      p-1 border border-slate-200 min-w-[120px]
                      ${isSelected ? 'bg-blue-100' : ''}
                      ${isFocused && !isSelected ? 'ring-2 ring-blue-400 ring-inset' : ''}
                    `}
                    onClick={(e) => handleCellClick(row.id, colIndex, e)}
                    onDoubleClick={() => handleCellDoubleClick(row.id, colIndex)}
                    onKeyDown={(e) => handleKeyDown(e, row.id, colIndex)}
                    tabIndex={0}
                  >
                    {isEditing ? (
                      <input
                        type="text"
                        defaultValue={cell.value}
                        autoFocus
                        className="w-full px-2 py-1 text-sm border border-blue-400 rounded outline-none"
                        onBlur={(e) => {
                          onUpdateCell(row.id, colIndex, e.target.value);
                          setEditingCell(null);
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            onUpdateCell(row.id, colIndex, e.currentTarget.value);
                            setEditingCell(null);
                          }
                        }}
                      />
                    ) : (
                      <span className={`text-sm ${cell.type === 'number' ? 'text-blue-700 font-mono' : 'text-slate-700'}`}>
                        {cell.value || <span className="text-slate-300">—</span>}
                      </span>
                    )}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};