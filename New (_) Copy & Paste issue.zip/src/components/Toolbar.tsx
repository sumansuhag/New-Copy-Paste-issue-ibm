import { Plus, Trash2, Copy, Code } from 'lucide-react';
import { Button } from '../components/ui/button';

interface ToolbarProps {
  onAddRow: () => void;
  onAddColumn: () => void;
  onDeleteRow: () => void;
  onDeleteColumn: () => void;
  onCopy: () => void;
  onToggleSyntax: () => void;
  showSyntax: boolean;
  hasSelection: boolean;
}

export const Toolbar = ({
  onAddRow,
  onAddColumn,
  onDeleteRow,
  onDeleteColumn,
  onCopy,
  onToggleSyntax,
  showSyntax,
  hasSelection,
}: ToolbarProps) => {
  return (
    <div className="flex items-center gap-2 p-3 bg-slate-100 border-b border-slate-300">
      <div className="flex items-center gap-1">
        <Button
          onClick={onAddRow}
          size="sm"
          variant="outline"
          className="bg-white hover:bg-slate-50 border-slate-300"
        >
          <Plus className="w-4 h-4 mr-1" />
          Add Row
        </Button>
        <Button
          onClick={onAddColumn}
          size="sm"
          variant="outline"
          className="bg-white hover:bg-slate-50 border-slate-300"
        >
          <Plus className="w-4 h-4 mr-1" />
          Add Column
        </Button>
      </div>
      
      <div className="w-px h-6 bg-slate-300 mx-2" />
      
      <div className="flex items-center gap-1">
        <Button
          onClick={onDeleteRow}
          size="sm"
          variant="outline"
          className="bg-white hover:bg-red-50 border-slate-300 hover:border-red-300 hover:text-red-600"
        >
          <Trash2 className="w-4 h-4 mr-1" />
          Delete Row
        </Button>
        <Button
          onClick={onDeleteColumn}
          size="sm"
          variant="outline"
          className="bg-white hover:bg-red-50 border-slate-300 hover:border-red-300 hover:text-red-600"
        >
          <Trash2 className="w-4 h-4 mr-1" />
          Delete Column
        </Button>
      </div>
      
      <div className="w-px h-6 bg-slate-300 mx-2" />
      
      <div className="flex items-center gap-1">
        <Button
          onClick={onCopy}
          size="sm"
          variant="outline"
          disabled={!hasSelection}
          className="bg-white hover:bg-blue-50 border-slate-300 hover:border-blue-300 hover:text-blue-600 disabled:opacity-50"
        >
          <Copy className="w-4 h-4 mr-1" />
          Copy Selection
        </Button>
        <Button
          onClick={onToggleSyntax}
          size="sm"
          variant={showSyntax ? 'default' : 'outline'}
          className={showSyntax ? 'bg-blue-600 hover:bg-blue-700' : 'bg-white hover:bg-slate-50 border-slate-300'}
        >
          <Code className="w-4 h-4 mr-1" />
          {showSyntax ? 'Hide Syntax' : 'Show Syntax'}
        </Button>
      </div>
      
      <div className="ml-auto text-sm text-slate-500">
        Ctrl+C to copy • Ctrl+V to paste
      </div>
    </div>
  );
};