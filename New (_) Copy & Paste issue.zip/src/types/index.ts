export interface Cell {
  value: string;
  type: 'string' | 'number';
}

export interface Row {
  id: string;
  cells: Cell[];
}

export interface Dataset {
  id: string;
  name: string;
  columns: string[];
  rows: Row[];
}

export interface Selection {
  startRow: number;
  endRow: number;
  startCol: number;
  endCol: number;
}

export interface ClipboardData {
  cells: Cell[][];
  timestamp: number;
}