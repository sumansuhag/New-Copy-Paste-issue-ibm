import { useState } from 'react';
import { useDatasets } from './hooks/useDatasets';
import { DatasetTabs } from './components/DatasetTabs';
import { DataGrid } from './components/DataGrid';
import { SyntaxPreview } from './components/SyntaxPreview';
import { Toolbar } from './components/Toolbar';

function App() {
  const {
    datasets,
    activeDataset,
    activeDatasetId,
    setActiveDatasetId,
    addDataset,
    updateCell,
    addRow,
    addColumn,
    deleteRow,
    deleteColumn,
    pasteData,
  } = useDatasets();

  const [showSyntax, setShowSyntax] = useState(false);
  const [hasSelection, setHasSelection] = useState(false);

  const handleDeleteRow = () => {
    if (activeDataset && activeDataset.rows.length > 0) {
      deleteRow(activeDatasetId, activeDataset.rows[activeDataset.rows.length - 1].id);
    }
  };

  const handleDeleteColumn = () => {
    if (activeDataset && activeDataset.columns.length > 0) {
      deleteColumn(activeDatasetId, activeDataset.columns.length - 1);
    }
  };

  const handleCopy = () => {
    // Copy is handled in DataGrid component
  };

  if (!activeDataset) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-slate-500">Loading datasets...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-300 px-6 py-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-lg">DC</span>
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-800">Data Clipboard</h1>
            <p className="text-sm text-slate-500">SPSS-style data copying tool</p>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-6">
        <div className="bg-white rounded-lg shadow-sm border border-slate-300 overflow-hidden">
          <DatasetTabs
            datasets={datasets}
            activeDatasetId={activeDatasetId}
            onSelectDataset={setActiveDatasetId}
            onAddDataset={addDataset}
          />
          
          <Toolbar
            onAddRow={() => addRow(activeDatasetId)}
            onAddColumn={() => addColumn(activeDatasetId)}
            onDeleteRow={handleDeleteRow}
            onDeleteColumn={handleDeleteColumn}
            onCopy={handleCopy}
            onToggleSyntax={() => setShowSyntax(!showSyntax)}
            showSyntax={showSyntax}
            hasSelection={hasSelection}
          />

          <div className="p-4">
            <DataGrid
              dataset={activeDataset}
              onUpdateCell={(rowId, colIndex, value) => updateCell(activeDatasetId, rowId, colIndex, value)}
              onPaste={(startRow, startCol, cells) => pasteData(activeDatasetId, startRow, startCol, cells)}
              onDeleteRow={(rowId) => deleteRow(activeDatasetId, rowId)}
              onDeleteColumn={(colIndex) => deleteColumn(activeDatasetId, colIndex)}
            />
          </div>

          {showSyntax && (
            <div className="px-4 pb-4">
              <SyntaxPreview dataset={activeDataset} />
            </div>
          )}
        </div>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg border border-slate-300">
            <h3 className="font-medium text-slate-800 mb-2">Quick Tips</h3>
            <ul className="text-sm text-slate-600 space-y-1">
              <li>• Click to select a cell</li>
              <li>• Shift+Click for range selection</li>
              <li>• Double-click to edit</li>
              <li>• Ctrl+C / Ctrl+V for copy/paste</li>
            </ul>
          </div>
          <div className="bg-white p-4 rounded-lg border border-slate-300">
            <h3 className="font-medium text-slate-800 mb-2">Current Dataset</h3>
            <div className="text-sm text-slate-600">
              <p><strong>Name:</strong> {activeDataset.name}</p>
              <p><strong>Rows:</strong> {activeDataset.rows.length}</p>
              <p><strong>Columns:</strong> {activeDataset.columns.length}</p>
            </div>
          </div>
          <div className="bg-white p-4 rounded-lg border border-slate-300">
            <h3 className="font-medium text-slate-800 mb-2">Data Types</h3>
            <div className="text-sm text-slate-600">
              <p><span className="inline-block w-3 h-3 bg-blue-100 rounded mr-1"></span> Numbers (blue)</p>
              <p><span className="inline-block w-3 h-3 bg-slate-100 rounded mr-1"></span> Strings (gray)</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;